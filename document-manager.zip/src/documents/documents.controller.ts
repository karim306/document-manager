import { 
    Controller, 
    Post, 
    Body, 
    UseInterceptors, 
    UploadedFile,
    Get,
    Param,
    Patch,
    Delete,
    Query
  } from '@nestjs/common';
  import { FileInterceptor } from '@nestjs/platform-express';
  import { DocumentsService } from './documents.service';
  import { CreateDocumentDto } from './dto/create-document.dto';
  
  @Controller('documents')
  export class DocumentsController {
    constructor(private readonly documentsService: DocumentsService) {}
  
    @Post('upload')
    @UseInterceptors(FileInterceptor('file'))
    async uploadDocument(
      @UploadedFile() file: Express.Multer.File,
      @Body() createDocumentDto: CreateDocumentDto,
    ) {
      return this.documentsService.uploadDocument(file, createDocumentDto);
    }
  
    @Get()
    findAll(@Query('folderId') folderId?: string) {
      return this.documentsService.findAll(folderId);
    }
  
    @Get(':id')
    findOne(@Param('id') id: string) {
      return this.documentsService.findOne(id);
    }
  
    @Patch(':id/tags/add')
    addTags(@Param('id') id: string, @Body() body: { tags: string[] }) {
      return this.documentsService.addTags(id, body.tags);
    }
  
    @Patch(':id/tags/remove')
    removeTags(@Param('id') id: string, @Body() body: { tags: string[] }) {
      return this.documentsService.removeTags(id, body.tags);
    }
  
    @Patch(':id/acl')
    updateACL(
      @Param('id') id: string, 
      @Body() body: { userId: string; permission: string }
    ) {
      return this.documentsService.updateDocumentACL(id, body.userId, body.permission);
    }
  
    @Delete(':id')
    removeDocument(@Param('id') id: string) {
      return this.documentsService.removeDocument(id);
    }
  }