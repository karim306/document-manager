import { Injectable, BadRequestException, NotFoundException } from '@nestjs/common';
import { CreateDocumentDto } from './dto/create-document.dto';
import { v4 as uuidv4 } from 'uuid';
import * as fs from 'fs';
import * as path from 'path';
import { FileValidator } from '../utils/file-validator';

@Injectable()
export class DocumentsService {
  private documents = [];
  private readonly documentStoragePath = './storage/documents';

  constructor() {
    // Create storage directory if it doesn't exist
    if (!fs.existsSync(this.documentStoragePath)) {
      fs.mkdirSync(this.documentStoragePath, { recursive: true });
    }
    
    // Load existing documents data if available
    try {
      if (fs.existsSync(path.join(this.documentStoragePath, 'documents.json'))) {
        this.documents = JSON.parse(
          fs.readFileSync(path.join(this.documentStoragePath, 'documents.json'), 'utf8')
        );
      } else {
        this.saveDocumentsData();
      }
    } catch (error) {
      console.error('Error loading documents data:', error);
      this.documents = [];
      this.saveDocumentsData();
    }
  }

  private saveDocumentsData() {
    fs.writeFileSync(
      path.join(this.documentStoragePath, 'documents.json'),
      JSON.stringify(this.documents, null, 2),
      'utf8'
    );
  }

  async uploadDocument(file: Express.Multer.File, createDocumentDto: CreateDocumentDto) {
    // Validate file
    const validation = FileValidator.validateFile(file);
    if (!validation.isValid) {
      // Remove uploaded file if validation fails
      fs.unlinkSync(file.path);
      throw new BadRequestException(validation.message);
    }

    // Generate unique ID
    const id = uuidv4();
    
    // Get file extension
    const extension = FileValidator.getFileExtension(file.mimetype);
    
    // Create document destination path
    const documentName = `${id}.${extension}`;
    const destinationPath = path.join(this.documentStoragePath, documentName);
    
    // Move file from temp uploads to documents folder
    fs.copyFileSync(file.path, destinationPath);
    fs.unlinkSync(file.path); // Remove from uploads

    // Create document metadata
    const document = {
      id,
      title: createDocumentDto.title,
      description: createDocumentDto.description,
      tags: createDocumentDto.tags || [],
      filename: file.originalname,
      path: `/storage/documents/${documentName}`,
      mimetype: file.mimetype,
      size: file.size,
      folderId: createDocumentDto.folderId || null,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      acl: [{
        userId: 'admin', // Default admin access
        permission: 'owner'
      }]
    };
// Add at the top of documents.service.ts
interface Document {
    id: string;
    title: string;
    description?: string;
    tags: string[];
    filename: string;
    path: string;
    mimetype: string;
    size: number;
    folderId: string | null;
    createdAt: string;
    updatedAt: string;
    acl: Array<{userId: string, permission: string}>;
  }
    // Save to local storage
    this.documents.push(document);
    this.saveDocumentsData();

    return document;
  }

  findAll(folderId?: string) {
    if (folderId) {
      return this.documents.filter(doc => doc.folderId === folderId);
    }
    return this.documents;
  }

  findOne(id: string) {
    const document = this.documents.find(doc => doc.id === id);
    if (!document) {
      throw new NotFoundException(`Document with ID ${id} not found`);
    }
    return document;
  }

  addTags(id: string, tags: string[]) {
    const document = this.findOne(id);
    const updatedTags = [...new Set([...document.tags, ...tags])];
    
    const updatedDocument = {
      ...document,
      tags: updatedTags,
      updatedAt: new Date().toISOString()
    };

    this.documents = this.documents.map(doc => 
      doc.id === id ? updatedDocument : doc
    );
    
    this.saveDocumentsData();
    return updatedDocument;
  }

  removeTags(id: string, tags: string[]) {
    const document = this.findOne(id);
    const updatedTags = document.tags.filter(tag => !tags.includes(tag));
    
    const updatedDocument = {
      ...document,
      tags: updatedTags,
      updatedAt: new Date().toISOString()
    };

    this.documents = this.documents.map(doc => 
      doc.id === id ? updatedDocument : doc
    );
    
    this.saveDocumentsData();
    return updatedDocument;
  }

  updateDocumentACL(id: string, userId: string, permission: string) {
    const document = this.findOne(id);
    
    // Remove existing access for this user
    const existingACL = document.acl.filter(entry => entry.userId !== userId);
    
    // Add new permission
    const updatedACL = [...existingACL, { userId, permission }];
    
    const updatedDocument = {
      ...document,
      acl: updatedACL,
      updatedAt: new Date().toISOString()
    };

    this.documents = this.documents.map(doc => 
      doc.id === id ? updatedDocument : doc
    );
    
    this.saveDocumentsData();
    return updatedDocument;
  }

  removeDocument(id: string) {
    const document = this.findOne(id);
    
    // Delete the file
    try {
      const filePath = path.join(process.cwd(), document.path.replace('/storage', 'storage'));
      if (fs.existsSync(filePath)) {
        fs.unlinkSync(filePath);
      }
    } catch (error) {
      console.error(`Error deleting file for document ${id}:`, error);
    }
    
    // Remove from documents list
    this.documents = this.documents.filter(doc => doc.id !== id);
    this.saveDocumentsData();
    
    return { message: `Document ${id} was deleted successfully` };
  }
}