import { 
    Controller, 
    Post, 
    Body, 
    Get, 
    Param, 
    Patch, 
    Delete,
    Query
  } from '@nestjs/common';
  import { FoldersService } from './folders.service';
  import { CreateFolderDto } from './dto/create-folder.dto';
  
  @Controller('folders')
  export class FoldersController {
    constructor(private readonly foldersService: FoldersService) {}
  
    @Post()
    createFolder(@Body() createFolderDto: CreateFolderDto) {
      return this.foldersService.createFolder(createFolderDto);
    }
  
    @Get()
    findAll(@Query('parentId') parentId?: string) {
      if (parentId === 'null' || parentId === undefined) {
        return this.foldersService.findChildren(null);
      } else {
        return this.foldersService.findChildren(parentId);
      }
    }
  
    @Get('all')
    getAllFolders() {
      return this.foldersService.findAll();
    }
  
    @Get(':id')
    findOne(@Param('id') id: string) {
      return this.foldersService.findOne(id);
    }
  
    @Patch(':id')
    updateFolder(
      @Param('id') id: string, 
      @Body() updateFolderDto: { name?: string; parentId?: string }
    ) {
      return this.foldersService.updateFolder(id, updateFolderDto);
    }
  
    @Delete(':id')
    removeFolder(@Param('id') id: string) {
      return this.foldersService.removeFolder(id);
    }
  }