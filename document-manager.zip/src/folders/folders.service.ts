import { Injectable, NotFoundException, BadRequestException } from '@nestjs/common';
import { CreateFolderDto } from './dto/create-folder.dto';
import { v4 as uuidv4 } from 'uuid';
import * as fs from 'fs';
import * as path from 'path';

@Injectable()
export class FoldersService {
  private folders = [];
  private readonly folderStoragePath = './storage/documents';

  constructor() {
    // Create storage directory if it doesn't exist
    if (!fs.existsSync(this.folderStoragePath)) {
      fs.mkdirSync(this.folderStoragePath, { recursive: true });
    }
    
    // Load existing folders data if available
    try {
      if (fs.existsSync(path.join(this.folderStoragePath, 'folders.json'))) {
        this.folders = JSON.parse(
          fs.readFileSync(path.join(this.folderStoragePath, 'folders.json'), 'utf8')
        );
      } else {
        this.saveFoldersData();
      }
    } catch (error) {
      console.error('Error loading folders data:', error);
      this.folders = [];
      this.saveFoldersData();
    }
  }

  private saveFoldersData() {
    fs.writeFileSync(
      path.join(this.folderStoragePath, 'folders.json'),
      JSON.stringify(this.folders, null, 2),
      'utf8'
    );
  }

  createFolder(createFolderDto: CreateFolderDto) {
    // Check if folder name already exists at the same level
    if (this.folders.some(folder => 
      folder.name === createFolderDto.name && 
      folder.parentId === createFolderDto.parentId
    )) {
      throw new BadRequestException(`A folder with name '${createFolderDto.name}' already exists in this location`);
    }
    
    // If parent folder is specified, check if it exists
    if (createFolderDto.parentId && 
        !this.folders.some(folder => folder.id === createFolderDto.parentId)) {
      throw new NotFoundException(`Parent folder with ID ${createFolderDto.parentId} not found`);
    }

    const folder = {
      id: uuidv4(),
      name: createFolderDto.name,
      parentId: createFolderDto.parentId || null,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    this.folders.push(folder);
    this.saveFoldersData();
    
    return folder;
  }

  findAll() {
    return this.folders;
  }

  findChildren(parentId: string | null) {
    return this.folders.filter(folder => folder.parentId === parentId);
  }

  findOne(id: string) {
    const folder = this.folders.find(folder => folder.id === id);
    if (!folder) {
      throw new NotFoundException(`Folder with ID ${id} not found`);
    }
    return folder;
  }

  updateFolder(id: string, updateFolderDto: { name?: string; parentId?: string }) {
    const folder = this.findOne(id);
    
    // Check if folder name already exists at the same level
    if (updateFolderDto.name && 
        this.folders.some(f => 
          f.name === updateFolderDto.name && 
          f.parentId === (updateFolderDto.parentId || folder.parentId) &&
          f.id !== id
        )) {
      throw new BadRequestException(`A folder with name '${updateFolderDto.name}' already exists in this location`);
    }
    
    // If parent folder is updated, check if it exists
    if (updateFolderDto.parentId && 
        !this.folders.some(f => f.id === updateFolderDto.parentId)) {
      throw new NotFoundException(`Parent folder with ID ${updateFolderDto.parentId} not found`);
    }
    
    // Prevent circular reference
    if (updateFolderDto.parentId === id) {
      throw new BadRequestException('A folder cannot be its own parent');
    }

    const updatedFolder = {
      ...folder,
      name: updateFolderDto.name || folder.name,
      parentId: updateFolderDto.parentId !== undefined ? updateFolderDto.parentId : folder.parentId,
      updatedAt: new Date().toISOString(),
    };

    this.folders = this.folders.map(f => f.id === id ? updatedFolder : f);
    this.saveFoldersData();
    
    return updatedFolder;
  }

  removeFolder(id: string) {
    // Check if folder exists
    this.findOne(id);
    
    // Check if folder has child folders
    if (this.folders.some(folder => folder.parentId === id)) {
      throw new BadRequestException('Cannot delete folder with subfolders');
    }
    
    // Delete folder
    this.folders = this.folders.filter(folder => folder.id !== id);
    this.saveFoldersData();
    
    return { message: `Folder ${id} was deleted successfully` };
  }
}